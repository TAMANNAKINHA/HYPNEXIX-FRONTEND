import { useState, useEffect, useMemo } from 'react'; // ← added useMemo
import { motion } from 'framer-motion';
import {
  CreditCard,
  Rocket,
  XCircle,
  ShieldAlert,
  Snowflake,
  RefreshCw,
  Copy,
  Check,
  Lock,
  Clock,
  ShieldCheck,
  ExternalLink,
  KeyRound,       // ← added
  PhoneCall,      // ← added
} from 'lucide-react';
import { useAegis, useOrchestrator } from '@/orchestrator';
import { formatINR } from '@/utils/format';
import { getPolicyByCategory } from '@/constants/policyProfiles';

const CATEGORY_META: Record<string, { icon: string; label: string }> = {
  cloud: { icon: '☁️', label: 'Cloud' },
  saas: { icon: '🤖', label: 'SaaS' },
  travel: { icon: '✈️', label: 'Travel' },
  payroll: { icon: '👨‍💼', label: 'Payroll' },
  procurement: { icon: '📦', label: 'Procurement' },
  marketing: { icon: '📢', label: 'Marketing' },
  professional: { icon: '💼', label: 'Professional' },
  general: { icon: '📄', label: 'General' },
};

// ============================================================
// 🧠 HELPER: Computes actual verification level (matches backend)
// ============================================================
function computeVerificationLevel(
  amount: number,
  thresholds: { otp: number; phone: number; manual: number },
  riskScore?: number
): { level: 0 | 1 | 2 | 3; label: string; description: string } {
  // Risk-based escalation (highest priority)
  if (riskScore !== undefined) {
    if (riskScore > 80) {
      return {
        level: 3,
        label: 'Manual Review',
        description: `High risk (${riskScore}%) – manual approval required.`,
      };
    }
    if (riskScore > 70) {
      return {
        level: 2,
        label: 'Phone Notification',
        description: `Moderate risk (${riskScore}%) – CFO will be alerted.`,
      };
    }
  }

  // Amount-based thresholds
  if (amount >= thresholds.manual) {
    return {
      level: 3,
      label: 'Manual Review',
      description: `₹${amount.toLocaleString()} exceeds manual review threshold of ₹${thresholds.manual.toLocaleString()}.`,
    };
  }
  if (amount >= thresholds.phone) {
    return {
      level: 2,
      label: 'Phone Notification',
      description: `₹${amount.toLocaleString()} exceeds phone notification threshold of ₹${thresholds.phone.toLocaleString()}.`,
    };
  }
  if (amount >= thresholds.otp) {
    return {
      level: 1,
      label: 'OTP Required',
      description: `₹${amount.toLocaleString()} exceeds OTP threshold of ₹${thresholds.otp.toLocaleString()}.`,
    };
  }
  return {
    level: 0,
    label: 'Auto-execute',
    description: `₹${amount.toLocaleString()} is below all verification thresholds.`,
  };
}

export function MissionWallet({ onViewPolicies }: { onViewPolicies: () => void }) {
  const { state } = useAegis();
  const { executeMission, cancelMission, unfreezeWallet, rotateSessionKey } = useOrchestrator();

  const [copied, setCopied] = useState(false);

  const mission = state.mission;
  const missionCategory = mission?.category;

  // Get policy based on category (memoized)
  const policy = useMemo(() => {
    return (missionCategory ? getPolicyByCategory(missionCategory) : null)
      || getPolicyByCategory('general')
      || {
          id: 'fallback',
          name: 'General',
          icon: '📄',
          defaultBudget: 10000,
          allowedVendors: [],
          verificationThresholds: { otp: 5000, phone: 10000, manual: 15000 },
          timelockSeconds: 60,
          trustRequirement: 'medium',
          fallback: 'manual_review',
        };
  }, [missionCategory]);

  // Compute dynamic verification level (memoized)
  const verification = useMemo(() => {
    if (!mission || !policy) return null;
    return computeVerificationLevel(
      mission.budget,
      policy.verificationThresholds,
      mission.riskScore // may be undefined
    );
  }, [mission, policy]);

  const totalTime = policy?.timelockSeconds || 60;
  const [localTimer, setLocalTimer] = useState(totalTime);
  const [lastMissionId, setLastMissionId] = useState(mission?.id);

  const missionStatus = mission?.status;
  const walletStatus = state.walletStatus;

  useEffect(() => {
    if (mission?.id && mission.id !== lastMissionId) {
      setLocalTimer(totalTime);
      setLastMissionId(mission.id);
    }
  }, [mission?.id, lastMissionId, totalTime]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;

    if (missionStatus === 'executing' && walletStatus !== 'frozen') {
      interval = setInterval(() => {
        setLocalTimer(prev => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    } else if (missionStatus === 'completed') {
      setLocalTimer(0);
    }

    return () => clearInterval(interval);
  }, [missionStatus, walletStatus]);

  // EMPTY STATE
  if (!mission || state.walletStatus === 'nuked') {
    return (
      <div className="flex flex-col items-center justify-center p-10 text-center opacity-70">
        <div className="h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center mb-4 border border-gold/20">
          <ShieldAlert className="h-8 w-8 text-gold" strokeWidth={1.5} />
        </div>
        <p className="text-[16px] font-bold text-white tracking-wide">No Active Mission Wallet</p>
      </div>
    );
  }

  const { timeLockRemaining = 0 } = state;
  const isExecuting = mission.status === 'executing' || timeLockRemaining > 0;
  const isFrozen = state.walletStatus === 'frozen' || mission.status === 'frozen';
  const isFailed = ['failed', 'nuked', 'cancelled'].includes(mission.status);
  const isCompleted = mission.status === 'completed';

  const handleCopyKey = () => {
    if (mission.sessionKey) {
      navigator.clipboard.writeText(mission.sessionKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const truncatedKey = mission.sessionKey
    ? `${mission.sessionKey.slice(0, 6)}...${mission.sessionKey.slice(-4)}`
    : 'None';

  const categoryMeta = mission.category ? CATEGORY_META[mission.category] : CATEGORY_META.general;

  const formattedExpiry = new Date(mission.expiry).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  let displayTime = totalTime;
  let progress = 100;
  let timerStatusText = 'Awaiting execution clearance...';
  let timerTheme = {
    border: 'border-warning/50',
    bg: 'bg-warning/10',
    text: 'text-warning',
    fill: 'bg-warning',
    ping: true,
  };

  if (isExecuting && !isFrozen) {
    displayTime = localTimer;
    progress = (localTimer / totalTime) * 100;
    timerStatusText = 'Smart contract time-lock active...';
  } else if (isFrozen) {
    displayTime = localTimer;
    progress = (localTimer / totalTime) * 100;
    timerStatusText = 'Time-lock PAUSED due to lockdown.';
    timerTheme = {
      border: 'border-error/50',
      bg: 'bg-error/10',
      text: 'text-error',
      fill: 'bg-error',
      ping: false,
    };
  } else if (isCompleted) {
    displayTime = 0;
    progress = 100;
    timerStatusText = 'Time-lock cleared. Funds securely released.';
    timerTheme = {
      border: 'border-success/50',
      bg: 'bg-success/10',
      text: 'text-success',
      fill: 'bg-success',
      ping: false,
    };
  } else if (isFailed) {
    displayTime = localTimer;
    progress = 100;
    timerStatusText = 'Mission aborted. Escrow locked.';
    timerTheme = {
      border: 'border-error/50',
      bg: 'bg-error/10',
      text: 'text-error',
      fill: 'bg-error',
      ping: false,
    };
  }

  // Determine styling for verification block based on level
  const levelClass =
    verification?.level === 0 ? 'border-success/20 bg-success/5' :
    verification?.level === 1 ? 'border-warning/20 bg-warning/5' :
    verification?.level === 2 ? 'border-warning/30 bg-warning/10' :
    'border-error/30 bg-error/10';

  return (
    <div className="flex flex-col p-6 relative overflow-hidden bg-bg-secondary/40 rounded-xl">
      {isFrozen && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-bg/95 backdrop-blur-lg p-6 text-center border-2 border-error/50">
          <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-error/15 border-2 border-error/40 text-error mb-4 animate-pulse shadow-[0_0_40px_rgba(239,68,68,0.3)]">
            <Snowflake className="h-10 w-10" />
          </div>
          <h3 className="text-xl font-black text-white uppercase tracking-widest">System Locked Down</h3>
          <p className="text-[12px] font-medium text-ink-dim max-w-[300px] mt-2 mb-8">
            Emergency override active. All transactions paused. If frozen for 20+ minutes, session keys auto-destruct.
          </p>
          <div className="flex w-full gap-3 max-w-[350px]">
            <button
              onClick={() => void unfreezeWallet()}
              className="flex-1 flex justify-center items-center gap-2 rounded-xl bg-success/20 border border-success/40 text-success px-4 py-3.5 text-[13px] font-bold hover:bg-success/30 transition-all"
            >
              <Snowflake className="h-4 w-4" /> Unfreeze
            </button>
            <button
              onClick={() => void rotateSessionKey()}
              className="flex-1 flex justify-center items-center gap-2 rounded-xl bg-gold/20 border border-gold/40 text-gold px-4 py-3.5 text-[13px] font-bold hover:bg-gold/30 transition-all"
            >
              <RefreshCw className="h-4 w-4" /> Rotate Key
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between border-b border-gold/15 pb-5">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/30 shadow-gold-sm">
            <CreditCard className="h-6 w-6 text-gold" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-[17px] font-black text-white tracking-wide">{mission.name}</h2>
            </div>
            <div className="flex items-center gap-2 mt-1.5">
              <span className="text-[11px] font-mono font-bold text-gold/60">{mission.missionId}</span>
              <span className="text-ink-faint">|</span>
              <button
                onClick={handleCopyKey}
                className="group flex items-center gap-1 font-mono text-[11px] font-medium text-ink-dim hover:text-white transition-colors bg-white/5 px-2 py-0.5 rounded"
              >
                <Lock className="h-3 w-3 text-gold/60" />
                <span>{truncatedKey}</span>
                {copied ? <Check className="h-3 w-3 text-success ml-1" /> : <Copy className="h-3 w-3 opacity-40 group-hover:opacity-100 ml-1" />}
              </button>
            </div>
          </div>
        </div>
        <StatusBadge status={mission.status} />
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <Detail label="Target Merchant" value={mission.merchant} />

        <div className="rounded-xl border-2 border-gold/60 bg-gold/10 p-4 shadow-[0_0_25px_rgba(212,175,55,0.15)] relative overflow-hidden transition-all hover:border-gold">
          <div className="absolute top-0 right-0 bg-gold text-black text-[9px] font-black px-2.5 py-1 rounded-bl-lg uppercase tracking-widest">
            Escrowed
          </div>
          <div className="text-[10px] uppercase tracking-widest text-gold font-bold mb-1.5">Budget Locked</div>
          <div className="text-2xl font-black text-white">{formatINR(mission.budget ?? 0)}</div>
        </div>

        <Detail label="Capital Deployed" value={formatINR(mission.spent ?? 0)} />
        <Detail label="Session Expiry" value={formattedExpiry} />
      </div>

      {/* ===== OPTIONAL BLOCKCHAIN EXPLORER LINK ===== */}
      {mission.explorerUrl && (
        <div className="mt-3 flex items-center justify-end">
          <a
            href={mission.explorerUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-[10px] text-gold/80 hover:text-gold transition-colors"
          >
            <ExternalLink className="h-3 w-3" />
            <span className="underline">View on BaseScan</span>
          </a>
        </div>
      )}

      <div className="mt-5 flex flex-col gap-3">
        <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/40 p-4">
          <div className="flex items-center gap-4">
            <div className="text-3xl drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]">{categoryMeta.icon}</div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-ink-faint font-bold mb-1">Authorized Scope</div>
              <div className="text-[15px] font-black text-white tracking-widest uppercase">{categoryMeta.label}</div>
            </div>
          </div>
          <div className="text-right flex flex-col items-end">
            <div className="text-[10px] uppercase tracking-widest text-ink-faint font-bold mb-1.5">Approved Vendors</div>
            <div className="flex flex-wrap justify-end gap-1.5 max-w-[180px]">
              {policy?.allowedVendors && policy.allowedVendors.length > 0 ? (
                policy.allowedVendors.map((vendor: string) => (
                  <span key={vendor} className="text-[9px] font-mono font-bold text-gold/90 bg-gold/10 border border-gold/20 px-1.5 py-0.5 rounded">
                    {vendor}
                  </span>
                ))
              ) : (
                <span className="text-[9px] font-mono text-white/70 bg-white/10 px-1.5 py-0.5 rounded">
                  Any Vendor (General)
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-warning/20 bg-warning/5 p-3.5 flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-warning/10 flex items-center justify-center border border-warning/20 text-warning">
              <Clock className="h-4 w-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-warning/70 font-bold mb-0.5">Execution Delay</div>
              <div className="text-[12px] font-bold text-white">{totalTime}-Sec Time-Lock</div>
            </div>
          </div>

          {/* ✅ DYNAMIC VERIFICATION BLOCK – replaces static threshold */}
          <div className={`rounded-xl border ${levelClass} p-3.5 flex items-center gap-3 transition-colors`}>
            <div className="h-8 w-8 rounded-full bg-success/10 flex items-center justify-center border border-success/20 text-success">
              {verification?.level === 0 && <Check className="h-4 w-4" />}
              {verification?.level === 1 && <KeyRound className="h-4 w-4" />}
              {verification?.level === 2 && <PhoneCall className="h-4 w-4" />}
              {verification?.level === 3 && <ShieldAlert className="h-4 w-4" />}
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-success/70 font-bold mb-0.5">
                Verification Rule
              </div>
              <div className="text-[12px] font-bold text-white">
                {verification?.label || 'Unknown'}
              </div>
              {verification?.description && (
                <div className="text-[10px] text-ink-faint mt-0.5">{verification.description}</div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className={`mt-5 rounded-2xl border-2 ${timerTheme.border} ${timerTheme.bg} p-5 shadow-lg relative overflow-hidden transition-colors duration-500`}>
        <div className="flex items-end justify-between mb-3 relative z-10">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              {timerTheme.ping && <div className={`h-3 w-3 rounded-full ${timerTheme.fill} animate-ping`} />}
              {!timerTheme.ping && <div className={`h-3 w-3 rounded-full ${timerTheme.fill}`} />}
              <span className={`text-[12px] font-black tracking-widest ${timerTheme.text} uppercase`}>Escrow Time-Lock</span>
            </div>
            <span className={`text-[10px] font-medium ${timerTheme.text} opacity-80`}>{timerStatusText}</span>
          </div>
          <span className={`text-3xl font-mono font-black ${timerTheme.text} tracking-tighter`}>
            00:{displayTime.toString().padStart(2, '0')}
          </span>
        </div>

        <div className="h-2.5 rounded-full bg-black/60 overflow-hidden relative z-10 shadow-inner">
          <motion.div
            className={`h-full ${timerTheme.fill}`}
            initial={{ width: '100%' }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: 'linear', duration: isExecuting && !isFrozen ? 1 : 0.3 }}
          />
        </div>
      </div>

      <div className="mt-8 flex gap-3">
        {mission.status === 'created' && (
          <>
            <button onClick={() => void executeMission()} className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gold text-bg py-4 text-[14px] font-black uppercase tracking-wider shadow-gold hover:scale-[1.02] transition-transform">
              <Rocket className="h-5 w-5" /> Execute
            </button>
            <button onClick={() => void cancelMission()} className="flex-1 flex items-center justify-center gap-2 rounded-xl border-2 border-white/10 text-white py-4 text-[14px] font-bold hover:bg-white/5 transition-colors">
              Cancel Mission
            </button>
          </>
        )}
        {isExecuting && !isFrozen && (
          <button onClick={() => void cancelMission()} className="w-full flex items-center justify-center gap-2 rounded-xl bg-error/90 text-white py-4 text-[14px] font-black uppercase tracking-wider transition-all hover:bg-error hover:scale-[1.01] hover:shadow-[0_0_30px_rgba(239,68,68,0.3)]">
            <XCircle className="h-5 w-5" /> Abort Transaction
          </button>
        )}
        {(isFailed || isCompleted) && (
          <button disabled className="w-full rounded-xl bg-white/5 border border-white/5 text-ink-faint py-4 text-[13px] font-bold uppercase tracking-widest cursor-not-allowed">
            Mission Lifecycle Concluded
          </button>
        )}
      </div>

      <div className="absolute top-5 right-5 text-[10px] font-mono font-bold tracking-widest text-ink-faint">
        <button onClick={onViewPolicies} className="underline hover:text-gold transition-colors uppercase">View Internal Policy</button>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-black/30 p-4">
      <div className="text-[10px] uppercase tracking-widest text-ink-dim font-bold mb-1.5">{label}</div>
      <div className="text-[14px] font-bold text-white">{value}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; border: string }> = {
    idle: { bg: 'bg-white/5', text: 'text-ink-faint', border: 'border-white/10' },
    created: { bg: 'bg-gold/10', text: 'text-gold', border: 'border-gold/30' },
    awaiting_otp: { bg: 'bg-warning/10', text: 'text-warning animate-pulse', border: 'border-warning/40' },
    awaiting_review: { bg: 'bg-warning/10', text: 'text-warning animate-pulse', border: 'border-warning/40' },
    executing: { bg: 'bg-warning/10', text: 'text-warning', border: 'border-warning/40' },
    completed: { bg: 'bg-success/10', text: 'text-success', border: 'border-success/40' },
    cancelled: { bg: 'bg-white/5', text: 'text-ink-dim', border: 'border-white/10' },
    failed: { bg: 'bg-error/10', text: 'text-error', border: 'border-error/30' },
    frozen: { bg: 'bg-error/15', text: 'text-error animate-pulse', border: 'border-error/50' },
    nuked: { bg: 'bg-error/20', text: 'text-error', border: 'border-error/50' },
  };
  const c = config[status] || config.idle;

  return (
    <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${c.bg} ${c.border} ${c.text}`}>
      {status.replace('_', ' ')}
    </div>
  );
}