import { Store } from '../store';
import { TerminalLogger } from './terminalLogger'; // ✅ Resolved server.ts export error
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const transporter = nodemailer.createTransport({
  service: process.env.SMTP_SERVICE || 'gmail',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const TARGET_EMAIL = process.env.CFO_EMAIL || 'sanskarmain16@gmail.com';

export const verificationService = {
  // Generate a random 6-digit OTP
  generateOTP(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  },

  // Send REAL Email OTP via Nodemailer
  async sendOtpEmail(otp: string): Promise<void> {
    try {
      await transporter.sendMail({
        from: `"Aegis Security Gateway" <${process.env.SMTP_USER}>`,
        to: TARGET_EMAIL,
        subject: '🚨 Aegis Mission Verification Code (OTP)',
        text: `Aegis Security Alert: Your verification code for the pending transaction is ${otp}. Do not share this code.`,
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px; background-color: #0b0b0b; color: #ffffff; border-radius: 8px;">
            <h2 style="color: #d4af37;">AEGIS Sovereign Security</h2>
            <p>A high-value autonomous mission requires your explicit authorization.</p>
            <div style="background: #181818; padding: 15px; border-radius: 6px; border: 1px solid rgba(212,175,55,0.3); text-align: center; margin: 20px 0;">
              <span style="font-size: 28px; font-weight: bold; letter-spacing: 6px; color: #f4d37a;">${otp}</span>
            </div>
            <p style="font-size: 12px; color: #888;">If you did not initiate this transaction, please freeze your wallet immediately via the dashboard.</p>
          </div>
        `
      });
      console.log(`✅ Real Email OTP sent successfully to ${TARGET_EMAIL}. Code: ${otp}`);
    } catch (error) {
      console.error('❌ Nodemailer Email Error:', error);
    }
  },

  initiateBrowserCall(roleName: string): void {
    console.log(`📞 [System] Emitting browser call notification for ${roleName}...`);
  },

  validateOTP(missionId: string, otp: string): boolean {
    const state = Store.getState();
    const mission = state.mission;
    
    if (!mission || mission.id !== missionId) {
      return false;
    }

    const expected = (mission as any).expectedOtp;
    const cleanInput = otp ? otp.trim() : '';

    if (expected && expected === cleanInput) {
      return true;
    }
    return false;
  },

  emitVerificationUpdate(missionId: string, payload: { level: string, message: string }) {
    TerminalLogger.broadcast('verification_update', { missionId, ...payload });
  }
};