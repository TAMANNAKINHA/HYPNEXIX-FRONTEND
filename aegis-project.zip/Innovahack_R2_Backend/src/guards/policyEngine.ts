import { Store } from '../store';

export class PolicyEngine {
  static async verify(amount: number, budget: number, merchant: string): Promise<boolean> {
    Store.updateShield('policyEngine', 'processing');
    await new Promise(r => setTimeout(r, 600));

    // Get the active policy (from the mission's category or default)
    const activePolicy = Store.getCurrentPolicy() || Store.getDefaultPolicy();
    const allowedVendors = activePolicy?.allowedVendors || [];

    // Check if the merchant is allowed
    if (!allowedVendors.includes(merchant)) {
      Store.updateShield('policyEngine', 'failure');
      Store.addLog(`Policy Violation: Merchant "${merchant}" not in allowlist.`, 'error');
      return false;
    }

    // Check budget against policy's default budget (or per-mission cap)
    const maxBudget = activePolicy?.defaultBudget || budget; // fallback
    if (amount > maxBudget) {
      Store.updateShield('policyEngine', 'failure');
      Store.addLog(`Policy Violation: Requested amount ₹${amount} exceeds policy budget of ₹${maxBudget}.`, 'error');
      return false;
    }

    Store.updateShield('policyEngine', 'success');
    Store.addLog('Policy Engine Passed: Merchant approved and amount within limits.', 'success');
    return true;
  }
}