import { Store } from '../store';
import { BlockchainService } from '../services/blockchainService';

export class CircuitBreaker {
  static async checkAndTrigger(walletAddress: string): Promise<boolean> {
    const state = Store.getState();
    
    if ((state.consecutiveFailures || 0) >= 2) {
      Store.updateShield('circuitBreaker', 'processing');
      await new Promise(r => setTimeout(r, 400));
      Store.updateShield('circuitBreaker', 'failure');
      Store.addLog('CIRCUIT BREAKER TRIPPED: Excessive failures. Freezing wallet on-chain.', 'error');
      
      const hash = await BlockchainService.triggerKillSwitch(walletAddress, 'freeze');
      Store.addAudit('Circuit Breaker Freeze', 'System', hash, 'blocked');
      Store.freezeWallet();
      
      return true;
    }
    
    Store.updateShield('circuitBreaker', 'success');
    return false;
  }
}