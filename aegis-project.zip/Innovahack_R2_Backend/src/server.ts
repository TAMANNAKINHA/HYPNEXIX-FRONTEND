import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { TerminalLogger } from './services/terminalLogger';
import { Store } from './store';
import missionRoutes from './routes/missionRoutes';
import attackRoutes from './routes/attackRoutes';

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Securely link logger to store
TerminalLogger.initialize(io, () => Store.getState());

app.use('/api/missions', missionRoutes);
app.use('/api/attacks', attackRoutes);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`AEGIS Backend Engine running on port ${PORT}`);
});