import { Request, Response } from 'express';
import { verificationService } from '../services/verificationService';
import { Store } from '../store';
import { finalizeMissionExecution } from './missionControllers'; 

export const verifyOtp = async (req: Request, res: Response) => {
  try {
    const { missionId, otp } = req.body;

    if (!missionId || !otp) {
      return res.status(400).json({ success: false, error: 'Mission ID and OTP are required.' });
    }

    // 1. Validate the OTP with the service mathematically
    const isValid = verificationService.validateOTP(missionId, otp);

    if (!isValid) {
      Store.addLog(`❌ OTP Verification Failed: Incorrect code entered for mission ${missionId}`, 'error');
      return res.status(400).json({ success: false, error: 'Invalid OTP code. Please check your Gmail inbox.' });
    }

    Store.addLog(`✓ OTP Verified successfully. Resuming execution gauntlet...`, 'success');

    // 2. Update status in memory
    const state = Store.getState();
    const mission = state.mission;
    
    if (mission) {
      mission.status = 'executing';
      Store.updateMission(mission);
    }

    // 3. Inform the frontend to close the prompt
    verificationService.emitVerificationUpdate(missionId, { 
      level: 'resolved', 
      message: 'OTP Verified. Resuming execution...' 
    });

    // 4. Resume Phase 2 of the gauntlet (Time Lock -> Circuit Breaker -> Blockchain)
    const result = await finalizeMissionExecution(missionId);

    if (!result.success) {
      return res.status(500).json({ success: false, error: result.error });
    }

    return res.status(200).json({ 
      success: true, 
      message: 'OTP verified, execution resumed.',
      txHash: result.txHash
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
};


export const rejectVerification = async (req: Request, res: Response) => {
  try {
    const { missionId } = req.body;
    const state = Store.getState();
    const mission = state.mission;

    if (mission) {
      Store.refundMission();
      mission.status = 'cancelled' as any;
      Store.updateMission(null);
      Store.addLog('Mission cancelled by user during verification prompt.', 'warning');
      Store.addAudit('Verification Rejected', 'operator', '0x...', 'warning');
    }

    verificationService.emitVerificationUpdate(missionId, { 
      level: 'rejected', 
      message: 'Mission rejected and cancelled.' 
    });

    return res.status(200).json({ success: true, message: 'Mission cancelled.' });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
};

export const verifyApprove = async (req: Request, res: Response) => {
  try {
    const { missionId } = req.body;
    const state = Store.getState();
    const mission = state.mission;

    if (!mission || mission.id !== missionId) {
      return res.status(404).json({ success: false, error: 'Mission not found or inactive.' });
    }

    if (mission.status !== 'awaiting_review') {
      return res.status(400).json({ 
        success: false, 
        error: `Mission is not awaiting manual review (current status: ${mission.status}).` 
      });
    }

    Store.addLog(`✅ Manual review approved for mission ${mission.name}. Resuming execution...`, 'success');

    // Inform frontend to close the prompt
    verificationService.emitVerificationUpdate(missionId, {
      level: 'resolved',
      message: 'Manual review approved. Resuming execution...'
    });

    // Resume the execution (Phase 2: Time Lock → Circuit Breaker → Blockchain)
    const result = await finalizeMissionExecution(missionId);

    if (!result.success) {
      return res.status(500).json({ success: false, error: result.error });
    }

    return res.status(200).json({
      success: true,
      message: 'Manual review approved, execution resumed.',
      txHash: result.txHash
    });
  } catch (error: any) {
    console.error('Approve error:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
};