import { AegisState, Mission, ShieldId, ShieldStatus, TerminalLog, ChatMessage, AuditEntry, PolicyProfile, MissionCategory } from './types';
import { TerminalLogger } from './services/terminalLogger';
import { getPolicyByCategory, getDefaultPolicy } from './constants/policyProfiles';

export class Store {
  private static state: Partial<AegisState> = {
    mission: null,
    walletStatus: 'empty',
    trustScore: 98,
    attackCount: 0,
    blockedCount: 0,
    consecutiveFailures: 0,
    reserveBalance: 1000000,
    allocatedBalance: 0,
    profile: {
      owner: 'Rajesh Sharma',
      role: 'Chief Financial Officer',
      enterprise: 'Apex Labs India Pvt Ltd',
      plan: 'Enterprise Sovereign',
      perMissionCap: 100000,
      dailyOutflowCeiling: 300000,
      dailySpent: 50000,
      highestSpend: 0,
    },
  };

  static getState() {
    return this.state;
  }

  static getPolicyForCategory(category: MissionCategory): PolicyProfile | undefined {
    return getPolicyByCategory(category);
  }

  static getDefaultPolicy(): PolicyProfile {
    return getDefaultPolicy();
  }

  static applyPolicyToMission(mission: Mission, policy: PolicyProfile): void {
    mission.category = policy.category as any;
    mission.policyId = policy.id;
  }

  static getCurrentPolicy(): PolicyProfile | undefined {
    const mission = this.state.mission;
    if (!mission || !mission.category) return undefined;
    return this.getPolicyForCategory(mission.category);
  }

  static updateMission(mission: Mission | null) {
    if (mission && mission.status === 'created' && (!this.state.mission || this.state.mission.id !== mission.id)) {
      this.state.allocatedBalance = (this.state.allocatedBalance || 0) + mission.budget;
      this.state.reserveBalance = (this.state.reserveBalance || 1000000) - mission.budget;
      TerminalLogger.broadcast('balance_update', { reserveBalance: this.state.reserveBalance, allocatedBalance: this.state.allocatedBalance });
    }

    this.state.mission = mission;
    if (mission) {
      this.state.walletStatus = mission.status === 'frozen' ? 'frozen' : mission.status === 'nuked' ? 'nuked' : 'active';
    } else {
      this.state.walletStatus = 'empty';
    }
    TerminalLogger.broadcast('mission_update', { mission: this.state.mission });
    TerminalLogger.broadcast('wallet_status', { status: this.state.walletStatus });
  }

  static refundMission() {
    // 🚨 FIX: Allow refunds for frozen, validating, and OTP statuses! Don't let the money vanish!
    const refundableStatuses = ['created', 'validating', 'awaiting_otp', 'awaiting_review', 'executing', 'frozen'];
    
    if (this.state.mission && refundableStatuses.includes(this.state.mission.status)) {
      this.state.reserveBalance = (this.state.reserveBalance || 0) + this.state.mission.budget;
      this.state.allocatedBalance = Math.max(0, (this.state.allocatedBalance || 0) - this.state.mission.budget);
      TerminalLogger.broadcast('balance_update', { reserveBalance: this.state.reserveBalance, allocatedBalance: this.state.allocatedBalance });
    }
  }

  static updateProfileStats(amountSpent: number) {
    if (this.state.profile) {
      this.state.profile.dailySpent += amountSpent;
      if (amountSpent > this.state.profile.highestSpend) {
        this.state.profile.highestSpend = amountSpent;
      }
      this.state.allocatedBalance = Math.max(0, (this.state.allocatedBalance || 0) - amountSpent);
      TerminalLogger.broadcast('profile_update', this.state.profile);
      TerminalLogger.broadcast('balance_update', { reserveBalance: this.state.reserveBalance, allocatedBalance: this.state.allocatedBalance });
    }
  }

  static updateShield(id: ShieldId, status: ShieldStatus) {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false });
    TerminalLogger.broadcast('shield_update', { id, status, lastCheck: time });
  }

  static addLog(message: string, severity: 'info' | 'success' | 'warning' | 'error' | 'gold') {
    const log: TerminalLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      message,
      severity,
      timestamp: Date.now(),
    };
    TerminalLogger.broadcast('log', log);
  }

  static addChat(role: 'user' | 'aegis', text: string) {
    const chat: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      role,
      text,
      timestamp: Date.now(),
    };
    TerminalLogger.broadcast('chat', chat);
  }

  static addAudit(action: string, actor: string, hash: string, result: 'success' | 'blocked' | 'warning') {
    const audit: AuditEntry = {
      id: `aud_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      action,
      actor,
      hash,
      result,
      timestamp: Date.now(),
    };
    TerminalLogger.broadcast('audit', audit);
  }

  static updateTrust(modifier: number) {
    this.state.trustScore = Math.max(0, Math.min(100, (this.state.trustScore || 100) + modifier));
    TerminalLogger.broadcast('trust_update', { trustScore: this.state.trustScore });
  }

  static incrementFailure() {
    this.state.consecutiveFailures = (this.state.consecutiveFailures || 0) + 1;
    this.state.blockedCount = (this.state.blockedCount || 0) + 1;
    this.state.attackCount = (this.state.attackCount || 0) + 1;
    TerminalLogger.broadcast('attack_stats', {
      attackCount: this.state.attackCount,
      blockedCount: this.state.blockedCount,
    });
  }

  static resetFailures() {
    this.state.consecutiveFailures = 0;
  }

  static freezeWallet() {
    if (this.state.mission) {
      this.state.mission.status = 'frozen';
    }
    this.state.walletStatus = 'frozen';
    TerminalLogger.broadcast('mission_update', { mission: this.state.mission });
    TerminalLogger.broadcast('wallet_status', { status: 'frozen' });
  }

  static unfreezeWallet() {
    if (this.state.mission) {
      this.state.mission.status = 'executing'; 
    }
    this.state.walletStatus = 'active';
    TerminalLogger.broadcast('mission_update', { mission: this.state.mission });
    TerminalLogger.broadcast('wallet_status', { status: 'active' });
  }

  static nukeWallet() {
    this.refundMission();
    this.state.mission = null;
    this.state.walletStatus = 'nuked';
    TerminalLogger.broadcast('mission_update', { mission: null });
    TerminalLogger.broadcast('wallet_status', { status: 'nuked' });
  }

  static resetDemoState() {
    this.state = {
      mission: null,
      walletStatus: 'empty',
      trustScore: 98,
      attackCount: 0,
      blockedCount: 0,
      consecutiveFailures: 0,
      reserveBalance: 1000000,
      allocatedBalance: 0,
      logs: [],
      audit: [],
      chat: [
        {
          id: `msg_${Date.now()}`,
          role: 'aegis',
          text: 'AEGIS demo reset. Issue a mission instruction to provision a Mission Wallet.',
          timestamp: Date.now(),
        },
      ],
      profile: {
        owner: 'Rajesh Sharma',
        role: 'Chief Financial Officer',
        enterprise: 'Apex Labs India Pvt Ltd',
        plan: 'Enterprise Sovereign',
        perMissionCap: 100000,
        dailyOutflowCeiling: 300000,
        dailySpent: 50000,
        highestSpend: 0,
      },
    };
    TerminalLogger.broadcast('state_reset', this.state);
    TerminalLogger.broadcast('balance_update', { reserveBalance: 1000000, allocatedBalance: 0 });
    TerminalLogger.broadcast('profile_update', this.state.profile);
    TerminalLogger.broadcast('wallet_status', { status: 'empty' });
    TerminalLogger.broadcast('mission_update', { mission: null });
    this.addLog('✨ Demo environment completely purged and reset to initial sovereign state.', 'success');
  }
}