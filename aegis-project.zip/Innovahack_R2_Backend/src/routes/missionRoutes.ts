import { Router } from 'express';
import { 
  createMission, 
  executeMission, 
  cancelMission, 
  freezeWallet, 
  unfreezeWallet, // ✅ Ensure Unfreeze is imported
  nukeWallet, 
  rotateSessionKey,
  getPolicies 
} from '../controllers/missionControllers';

// Import verification controllers assuming they exist in your file structure
import { verifyOtp, rejectVerification, verifyApprove } from '../controllers/verificationControllers';

const router = Router();

// Standard Mission Flow Routes
router.post('/create', createMission);
router.post('/execute', executeMission);
router.post('/cancel', cancelMission);
router.post('/freeze', freezeWallet);
router.post('/unfreeze', unfreezeWallet); // ✅ Route fully mapped
router.post('/nuke', nukeWallet);
router.post('/rotate-key', rotateSessionKey);
router.get('/policies', getPolicies);

// Verification Routes
router.post('/verify/otp', verifyOtp);
router.post('/verify/reject', rejectVerification);
router.post('/verify/approve', verifyApprove);

export default router;